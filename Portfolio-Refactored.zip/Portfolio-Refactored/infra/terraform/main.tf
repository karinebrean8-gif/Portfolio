variable "aws_region" { type = string; default = "ap-southeast-1" }
variable "site_bucket_name" { type = string; description = "Globally unique S3 bucket name" }
provider "aws" { region = var.aws_region }
resource "aws_s3_bucket" "site" { bucket = var.site_bucket_name }
resource "aws_s3_bucket_public_access_block" "site" { bucket = aws_s3_bucket.site.id; block_public_acls = true; block_public_policy = true; ignore_public_acls = true; restrict_public_buckets = true }
output "bucket_name" { value = aws_s3_bucket.site.id }
