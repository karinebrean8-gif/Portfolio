SHELL := /bin/sh
.PHONY: install check build docker-build
install:
	npm install --no-audit --no-fund
check:
	npm run check
build:
	npm run build
docker-build:
	docker build -t portfolio:local .
