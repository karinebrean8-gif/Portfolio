import './App.css'
import { CaseStudiesPage } from './components/features/caseStudies/CaseStudiesPage.jsx'
import { CertificationsPage } from './components/features/certifications/CertificationsPage.jsx'
import { ExperiencePage } from './components/features/experience/ExperiencePage.jsx'
import { ProjectsPage } from './components/features/projects/ProjectsPage.jsx'
import { SkillsPage } from './components/features/skills/SkillsPage.jsx'
import { Footer } from './components/layout/footer.jsx'
import { Navbar } from './components/layout/navbar.jsx'
import { ContactForm } from './components/ui/contact.jsx'
import { profile } from './data/portfolio.js'

function App() {
  return <div id="top" className="min-h-screen bg-slate-950 text-slate-100"><Navbar/><main><section id="about" className="relative overflow-hidden border-b border-slate-800"><div className="mx-auto grid min-h-[70vh] max-w-6xl items-center gap-10 px-4 py-20 md:grid-cols-[1.4fr_1fr]"><div><p className="section-kicker">{profile.location} · Available for meaningful engineering work</p><h1 className="mt-4 max-w-4xl text-5xl font-black tracking-tight text-white sm:text-7xl">Build reliable products. Explain every decision.</h1><p className="mt-6 max-w-2xl text-lg leading-8 text-slate-300">{profile.summary}</p><div className="mt-8 flex flex-wrap gap-4"><a className="rounded-lg bg-cyan-400 px-5 py-3 font-bold text-slate-950 hover:bg-cyan-300" href="#projects">View projects</a><a className="rounded-lg border border-slate-700 px-5 py-3 font-bold hover:border-cyan-400" href={profile.links.github} target="_blank" rel="noreferrer">GitHub profile</a></div></div><div className="rounded-3xl border border-cyan-400/20 bg-gradient-to-br from-cyan-400/10 to-indigo-500/10 p-8"><p className="text-sm uppercase tracking-[0.25em] text-cyan-300">Current focus</p><ul className="mt-6 grid gap-4 text-slate-200">{['Accessible React interfaces','Clean, testable boundaries','Practical cloud delivery','Truthful technical documentation'].map((item) => <li key={item} className="rounded-xl bg-slate-900/80 p-4">{item}</li>)}</ul></div></div></section><ProjectsPage/><SkillsPage/><ExperiencePage/><CertificationsPage/><CaseStudiesPage/><section id="contact" className="scroll-mt-24 border-t border-slate-800 py-16"><div className="mx-auto grid max-w-6xl gap-10 px-4 md:grid-cols-2"><div><p className="section-kicker">Contact</p><h2 className="section-title">Let’s discuss the problem before choosing the technology</h2><p className="mt-4 text-slate-300">Email: <a className="text-cyan-300" href={`mailto:${profile.email}`}>{profile.email}</a></p></div><ContactForm email={profile.email}/></div></section></main><Footer/></div>
}
export default App
