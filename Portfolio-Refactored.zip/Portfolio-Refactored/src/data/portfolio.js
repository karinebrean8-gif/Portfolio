export const profile = Object.freeze({
  name: 'Shakib Mia',
  role: 'Full-stack Software Engineer',
  summary: 'I design maintainable web products with React, Node.js, cloud infrastructure, and pragmatic engineering practices.',
  location: 'Bangladesh',
  email: import.meta.env.VITE_CONTACT_EMAIL || 'hello@example.com',
  links: {
    github: import.meta.env.VITE_GITHUB_URL || 'https://github.com/shakib-mia765',
    linkedin: import.meta.env.VITE_LINKEDIN_URL || 'https://www.linkedin.com/',
  },
})

export const navigation = Object.freeze([
  { label: 'About', href: '#about' },
  { label: 'Projects', href: '#projects' },
  { label: 'Skills', href: '#skills' },
  { label: 'Experience', href: '#experience' },
  { label: 'Certifications', href: '#certifications' },
  { label: 'Contact', href: '#contact' },
])

export const projects = Object.freeze([
  {
    id: 'portfolio-platform',
    title: 'Portfolio Platform',
    description: 'A responsive, accessible portfolio organized around reusable feature modules and data-driven components.',
    technologies: ['React', 'Vite', 'Tailwind CSS', 'Vitest'],
    repositoryUrl: 'https://github.com/shakib-mia765/Portfolio',
    highlights: ['Feature-oriented UI', 'Automated quality checks', 'Container-ready build'],
  },
  {
    id: 'cloud-delivery',
    title: 'Cloud Delivery Blueprint',
    description: 'Infrastructure examples for container delivery using Docker, Kubernetes, and Terraform.',
    technologies: ['Docker', 'Kubernetes', 'Terraform'],
    repositoryUrl: 'https://github.com/shakib-mia765/Portfolio/tree/main/infra',
    highlights: ['Health checks', 'Resource boundaries', 'Repeatable environments'],
  },
])

export const skills = Object.freeze([
  { category: 'Frontend', items: ['React', 'JavaScript', 'HTML', 'CSS', 'Tailwind CSS'] },
  { category: 'Backend', items: ['Node.js', 'REST APIs', 'PostgreSQL', 'Prisma'] },
  { category: 'Platform', items: ['Docker', 'Kubernetes', 'Terraform', 'CI/CD'] },
  { category: 'Quality', items: ['Vitest', 'Playwright', 'Clean Architecture', 'Accessibility'] },
])

export const experiences = Object.freeze([
  {
    id: 'independent-engineer',
    role: 'Independent Software Engineer',
    organization: 'Portfolio and product development',
    period: 'Present',
    achievements: [
      'Builds modular user interfaces with reusable components and predictable data flow.',
      'Documents architectural decisions and validates changes with automated checks.',
      'Creates deployment-ready infrastructure examples without presenting unverified production claims.',
    ],
  },
])

export const certifications = Object.freeze([
  { id: 'cloud', title: 'Cloud Engineering', issuer: 'Verified learning providers', skills: ['Cloud fundamentals', 'Infrastructure'] },
  { id: 'frontend', title: 'Frontend Development', issuer: 'Verified learning providers', skills: ['React', 'JavaScript'] },
  { id: 'backend', title: 'Backend Development', issuer: 'Verified learning providers', skills: ['APIs', 'Databases'] },
])

export const caseStudies = Object.freeze([
  {
    id: 'portfolio-refactor',
    title: 'Portfolio architecture refactor',
    problem: 'The original repository mixed framework concerns, oversized files, and unverified architecture language.',
    solution: 'Consolidated the application around Vite and React, moved infrastructure configuration to standard locations, and converted pages into small data-driven components.',
    tradeOffs: ['Kept the existing feature folder layout', 'Removed unused framework-specific configuration', 'Favored clarity over inflated terminology'],
    lessons: ['Executable code is stronger evidence than ambitious naming', 'Documentation must match the repository', 'Small modules are easier to test and review'],
  },
])
