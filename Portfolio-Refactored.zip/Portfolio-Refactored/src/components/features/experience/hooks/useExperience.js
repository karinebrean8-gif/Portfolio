import { experiences } from '../../../../data/portfolio.js'
export function useExperience() { return { experiences, isLoading: false, error: null } }
