import { useMemo } from 'react'
export function useExperienceFilter(experiences, query = '') { return useMemo(() => experiences.filter((item) => `${item.role} ${item.organization}`.toLowerCase().includes(query.toLowerCase())), [experiences, query]) }
