import { experiences } from '../../../../data/portfolio.js'
export const experienceApi = Object.freeze({ list: async () => Promise.resolve([...experiences]) })
