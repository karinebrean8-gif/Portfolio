export const trackExperienceView = (id, logger = console) => logger.info('experience_view', { id })
