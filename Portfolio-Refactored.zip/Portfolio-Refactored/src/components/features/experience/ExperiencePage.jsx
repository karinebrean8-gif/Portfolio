import { ExperienceTimeline } from './components/ExperienceTimeline.jsx'
import { useExperience } from './hooks/useExperience.js'
export function ExperiencePage() { const { experiences } = useExperience(); return <section id="experience" className="scroll-mt-24 py-16"><div className="mx-auto max-w-6xl px-4"><p className="section-kicker">Experience</p><h2 className="section-title">Focused on maintainable delivery</h2><div className="mt-8"><ExperienceTimeline experiences={experiences}/></div></div></section> }
export default ExperiencePage
