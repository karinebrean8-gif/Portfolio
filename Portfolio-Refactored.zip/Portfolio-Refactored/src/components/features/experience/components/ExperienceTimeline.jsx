import { ExperienceCard } from './ExperienceCard.jsx'
export function ExperienceTimeline({ experiences = [] }) { return <div className="grid gap-5">{experiences.map((experience) => <ExperienceCard key={experience.id} experience={experience}/>)}</div> }
