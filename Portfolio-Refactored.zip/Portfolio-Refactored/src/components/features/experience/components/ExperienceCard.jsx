import { Card } from '../../../ui/card.jsx'
import { AchievementList } from './AchievementList.jsx'
export function ExperienceCard({ experience }) { return <Card><div className="flex flex-wrap justify-between gap-3"><div><h3 className="text-xl font-bold">{experience.role}</h3><p className="text-cyan-300">{experience.organization}</p></div><p className="text-sm text-slate-400">{experience.period}</p></div><AchievementList achievements={experience.achievements}/></Card> }
