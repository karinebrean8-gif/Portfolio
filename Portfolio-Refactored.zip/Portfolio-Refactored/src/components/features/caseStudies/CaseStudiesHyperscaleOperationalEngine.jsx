export { CaseStudiesPage as default, CaseStudiesPage } from './CaseStudiesPage.jsx'
