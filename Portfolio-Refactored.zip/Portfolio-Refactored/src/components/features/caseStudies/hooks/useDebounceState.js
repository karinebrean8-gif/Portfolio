import { useEffect, useState } from 'react'
export function useDebounceState(value, delay = 250) { const [debouncedValue, setDebouncedValue] = useState(value); useEffect(() => { const timer = window.setTimeout(() => setDebouncedValue(value), delay); return () => window.clearTimeout(timer) }, [value, delay]); return debouncedValue }
