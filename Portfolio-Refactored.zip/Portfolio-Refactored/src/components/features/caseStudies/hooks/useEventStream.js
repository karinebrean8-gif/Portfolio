import { useEffect, useState } from 'react'
export function useEventStream(url) { const [events, setEvents] = useState([]); useEffect(() => { if (!url || typeof EventSource === 'undefined') return undefined; const stream = new EventSource(url); stream.onmessage = ({ data }) => setEvents((current) => [...current, data]); return () => stream.close() }, [url]); return events }
