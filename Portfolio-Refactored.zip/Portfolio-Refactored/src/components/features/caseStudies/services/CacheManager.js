export class CacheManager { #values = new Map(); get(key) { return this.#values.get(key) } set(key, value) { this.#values.set(key, value); return value } clear() { this.#values.clear() } }
