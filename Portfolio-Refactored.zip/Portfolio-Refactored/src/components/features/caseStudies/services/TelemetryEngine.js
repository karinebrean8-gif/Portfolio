export const createTelemetry = (sink = console) => Object.freeze({ track: (event, properties = {}) => sink.info('[telemetry]', { event, properties, timestamp: new Date().toISOString() }) })
