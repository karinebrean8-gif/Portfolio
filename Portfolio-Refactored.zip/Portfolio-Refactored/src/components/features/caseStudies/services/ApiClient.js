import { requestJson } from '../../../../lib/http.js'
export const apiClient = Object.freeze({ get: (url) => requestJson(url), post: (url, body) => requestJson(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }) })
