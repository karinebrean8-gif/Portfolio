import { caseStudies } from '../../../data/portfolio.js'
import { CaseStudyDetails } from './components/CaseStudyDetails.jsx'
export function CaseStudiesPage() { return <section id="case-studies" className="scroll-mt-24 py-16"><div className="mx-auto max-w-6xl px-4"><p className="section-kicker">Engineering decisions</p><h2 className="section-title">Case study</h2><div className="mt-8 rounded-2xl border border-slate-800 bg-slate-900/60 p-6"><h3 className="text-2xl font-bold">{caseStudies[0].title}</h3><div className="mt-6"><CaseStudyDetails caseStudy={caseStudies[0]} /></div></div></div></section> }
export default CaseStudiesPage
