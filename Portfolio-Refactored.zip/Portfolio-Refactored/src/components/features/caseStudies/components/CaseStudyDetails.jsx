import { ArchitectureBreakdown } from './ArchitectureBreakdown.jsx'
import { LessonsLearned } from './LessonsLearned.jsx'
import { ProblemStatement } from './ProblemStatement.jsx'
import { SolutionOverview } from './SolutionOverview.jsx'
import { TradeOffAnalysis } from './TradeOffAnalysis.jsx'
export function CaseStudyDetails({ caseStudy }) { return <div className="grid gap-5"><ProblemStatement problem={caseStudy.problem}/><SolutionOverview solution={caseStudy.solution}/><ArchitectureBreakdown details="Feature modules depend on stable shared UI and data boundaries."/><TradeOffAnalysis tradeOffs={caseStudy.tradeOffs}/><LessonsLearned lessons={caseStudy.lessons}/></div> }
