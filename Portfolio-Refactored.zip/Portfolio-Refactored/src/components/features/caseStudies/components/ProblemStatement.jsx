export function ProblemStatement({ problem }) { return <section><h3 className="text-lg font-semibold text-cyan-300">Problem</h3><p className="mt-2 text-slate-300">{problem}</p></section> }
