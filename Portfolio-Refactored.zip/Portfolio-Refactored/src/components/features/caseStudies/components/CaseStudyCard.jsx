import { Card } from '../../../ui/card.jsx'
export function CaseStudyCard({ caseStudy }) { return <Card><h3 className="text-xl font-bold">{caseStudy.title}</h3><p className="mt-3 text-slate-300">{caseStudy.problem}</p></Card> }
