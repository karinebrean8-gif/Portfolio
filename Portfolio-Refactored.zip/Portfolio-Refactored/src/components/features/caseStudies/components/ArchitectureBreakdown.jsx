export function ArchitectureBreakdown({ details }) { return <section><h3 className="text-lg font-semibold text-cyan-300">Architecture</h3><p className="mt-2 text-slate-300">{details}</p></section> }
