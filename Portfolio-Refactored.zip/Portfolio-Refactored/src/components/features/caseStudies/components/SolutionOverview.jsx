export function SolutionOverview({ solution }) { return <section><h3 className="text-lg font-semibold text-cyan-300">Solution</h3><p className="mt-2 text-slate-300">{solution}</p></section> }
