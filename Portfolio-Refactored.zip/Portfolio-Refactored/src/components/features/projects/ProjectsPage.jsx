import { ProjectFilters } from './components/ProjectFilters.jsx'
import { ProjectGrid } from './components/ProjectGrid.jsx'
import { ProjectSearch } from './components/ProjectSearch.jsx'
import { useProjects } from './hooks/useProjects.js'
export function ProjectsPage() { const state = useProjects(); return <section id="projects" className="scroll-mt-24 py-16"><div className="mx-auto max-w-6xl px-4"><p className="section-kicker">Selected work</p><h2 className="section-title">Projects built around clear outcomes</h2><div className="mt-8 grid gap-4 md:grid-cols-[1fr_auto] md:items-end"><ProjectSearch value={state.query} onChange={state.setQuery}/><ProjectFilters technologies={state.technologies} active={state.technology} onChange={state.setTechnology}/></div><div className="mt-8"><ProjectGrid projects={state.projects}/></div></div></section> }
export default ProjectsPage
