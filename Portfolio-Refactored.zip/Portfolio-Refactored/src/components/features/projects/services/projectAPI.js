import { projects } from '../../../../data/portfolio.js'
export const projectApi = Object.freeze({ list: async () => Promise.resolve([...projects]), findById: async (id) => Promise.resolve(projects.find((project) => project.id === id) || null) })
