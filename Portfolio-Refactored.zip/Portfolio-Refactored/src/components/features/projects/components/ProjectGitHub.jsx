export function ProjectGitHub({ url }) { return <a className="text-sm font-semibold text-cyan-300 hover:text-cyan-200" href={url} target="_blank" rel="noreferrer">View source →</a> }
