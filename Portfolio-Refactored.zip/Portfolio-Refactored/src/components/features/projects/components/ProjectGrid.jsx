import { ProjectCard } from './ProjectCard.jsx'
export function ProjectGrid({ projects = [] }) { return <div className="grid gap-6 md:grid-cols-2">{projects.map((project) => <ProjectCard key={project.id} project={project}/>)}</div> }
