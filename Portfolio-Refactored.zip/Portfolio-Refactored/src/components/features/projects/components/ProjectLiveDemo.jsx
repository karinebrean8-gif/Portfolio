export function ProjectLiveDemo({ liveUrl }) { return liveUrl ? <p className="text-sm text-slate-300">{Array.isArray(liveUrl) ? liveUrl.join(' · ') : liveUrl}</p> : null }
