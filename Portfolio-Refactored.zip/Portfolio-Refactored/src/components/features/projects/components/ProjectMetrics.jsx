export function ProjectMetrics({ metrics }) { return metrics ? <p className="text-sm text-slate-300">{Array.isArray(metrics) ? metrics.join(' · ') : metrics}</p> : null }
