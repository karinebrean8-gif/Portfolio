export function ProjectDetails({ description }) { return description ? <p className="text-sm text-slate-300">{Array.isArray(description) ? description.join(' · ') : description}</p> : null }
