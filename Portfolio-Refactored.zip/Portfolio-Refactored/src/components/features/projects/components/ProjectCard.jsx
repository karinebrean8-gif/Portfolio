import { Card } from '../../../ui/card.jsx'
import { ProjectGitHub } from './ProjectGitHub.jsx'
import { ProjectTechStack } from './ProjectTechStack.jsx'
export function ProjectCard({ project }) { return <Card className="flex h-full flex-col"><h3 className="text-xl font-bold">{project.title}</h3><p className="mt-3 flex-1 text-slate-300">{project.description}</p><div className="mt-5"><ProjectTechStack technologies={project.technologies}/></div><ul className="my-5 list-disc space-y-1 pl-5 text-sm text-slate-400">{project.highlights.map((item) => <li key={item}>{item}</li>)}</ul><ProjectGitHub url={project.repositoryUrl}/></Card> }
