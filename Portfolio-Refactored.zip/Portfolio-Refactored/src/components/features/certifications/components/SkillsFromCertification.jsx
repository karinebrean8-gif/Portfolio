export function SkillsFromCertification({ skills = [] }) { return <p className="text-sm text-slate-300">{skills.join(' · ')}</p> }
