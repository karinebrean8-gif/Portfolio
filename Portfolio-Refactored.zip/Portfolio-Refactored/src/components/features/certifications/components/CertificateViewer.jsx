export function CertificateViewer({ title, url }) { return url ? <a className="text-cyan-300" href={url} target="_blank" rel="noreferrer">View {title}</a> : null }
