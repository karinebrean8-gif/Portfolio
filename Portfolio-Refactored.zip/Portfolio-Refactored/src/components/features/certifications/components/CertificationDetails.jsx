export function CertificationDetails({ certification }) { return <div><h3 className="text-xl font-bold">{certification.title}</h3><p className="text-slate-400">{certification.issuer}</p></div> }
