import { certifications } from '../../../data/portfolio.js'
import { CertificationCard } from './components/CertificationCard.jsx'
export function CertificationsPage() { return <section id="certifications" className="scroll-mt-24 py-16"><div className="mx-auto max-w-6xl px-4"><p className="section-kicker">Continuous learning</p><h2 className="section-title">Verified skills, presented without inflated claims</h2><div className="mt-8 grid gap-5 md:grid-cols-3">{certifications.map((certification) => <CertificationCard key={certification.id} certification={certification}/>)}</div></div></section> }
export default CertificationsPage
