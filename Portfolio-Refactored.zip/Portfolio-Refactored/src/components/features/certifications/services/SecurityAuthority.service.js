export const isSafeExternalUrl = (value) => { try { return ['https:'].includes(new URL(value).protocol) } catch { return false } }
