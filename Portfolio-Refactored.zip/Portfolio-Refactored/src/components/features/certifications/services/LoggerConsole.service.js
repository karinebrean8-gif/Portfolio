export const logger = Object.freeze({ info: (message, context = {}) => console.info(message, context), error: (message, context = {}) => console.error(message, context) })
