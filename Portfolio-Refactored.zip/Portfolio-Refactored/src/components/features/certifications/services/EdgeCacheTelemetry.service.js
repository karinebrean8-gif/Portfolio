export const edgeCacheTelemetry = Object.freeze({ record: (metric, value, sink = console) => sink.info('cache_metric', { metric, value }) })
