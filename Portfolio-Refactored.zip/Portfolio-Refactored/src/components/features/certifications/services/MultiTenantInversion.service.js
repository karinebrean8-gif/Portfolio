export const createServiceContainer = (services = {}) => Object.freeze({ ...services })
