import { useMemo } from 'react'
export function useVirtualScrollManager(items, start = 0, size = items.length) { return useMemo(() => items.slice(start, start + size), [items, start, size]) }
