import { useCallback } from 'react'
export function useTelemetryPipeline(logger = console) { return useCallback((event, properties = {}) => logger.info(event, properties), [logger]) }
