import { useMemo } from 'react'
export function useClusterMatrix(items = [], getKey = (item) => item.id) { return useMemo(() => new Map(items.map((item) => [getKey(item), item])), [items, getKey]) }
