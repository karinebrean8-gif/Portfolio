export { CertificationsPage as default, CertificationsPage } from './CertificationsPage.jsx'
