import { Card } from '../../../ui/card.jsx'
export function SkillCard({ skill }) { return <Card><h3 className="font-bold text-cyan-300">{skill.category}</h3><ul className="mt-4 flex flex-wrap gap-2">{skill.items.map((item) => <li key={item} className="rounded-md bg-slate-800 px-3 py-1 text-sm text-slate-200">{item}</li>)}</ul></Card> }
