import { SkillCard } from './SkillCard.jsx'
export function TechStackVisualizer({ skills = [] }) { return <div className="grid gap-5 md:grid-cols-2">{skills.map((skill) => <SkillCard key={skill.category} skill={skill}/>)}</div> }
