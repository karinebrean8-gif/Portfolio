export { SkillsPage as default, SkillsPage } from './SkillsPage.jsx'
