export const validateRequiredFields = (value, fields) => { const missing = fields.filter((field) => value?.[field] == null || value[field] === ''); return { valid: missing.length === 0, missing } }
