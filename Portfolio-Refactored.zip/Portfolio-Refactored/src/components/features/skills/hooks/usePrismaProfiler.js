import { useMemo } from 'react'
export function usePrismaProfiler(samples = []) { return useMemo(() => ({ count: samples.length, averageDuration: samples.length ? samples.reduce((total, sample) => total + sample.duration, 0) / samples.length : 0 }), [samples]) }
