import { skills } from '../../../data/portfolio.js'
import { TechStackVisualizer } from './components/TechStackVisualizer.jsx'
export function SkillsPage() { return <section id="skills" className="scroll-mt-24 py-16"><div className="mx-auto max-w-6xl px-4"><p className="section-kicker">Capabilities</p><h2 className="section-title">A balanced product engineering toolkit</h2><div className="mt-8"><TechStackVisualizer skills={skills}/></div></div></section> }
export default SkillsPage
