import { profile } from '../../data/portfolio.js'
export function Footer() { return <footer className="border-t border-slate-800 py-8 text-center text-sm text-slate-400"><p>© {new Date().getFullYear()} {profile.name}. Built with React, Vite, and Tailwind CSS.</p></footer> }
export default Footer
