import { navigation } from '../../data/portfolio.js'
export function Sidebar() { return <aside className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4"><p className="mb-3 text-xs font-semibold uppercase tracking-widest text-cyan-300">On this page</p><ul className="grid gap-2">{navigation.map((item) => <li key={item.href}><a className="text-sm text-slate-300 hover:text-white" href={item.href}>{item.label}</a></li>)}</ul></aside> }
export default Sidebar
