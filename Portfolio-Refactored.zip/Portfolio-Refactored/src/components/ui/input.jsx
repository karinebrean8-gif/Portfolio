export function Input({ label, id, className = '', ...props }) {
  return <label className="grid gap-2 text-sm font-medium text-slate-200" htmlFor={id}>{label}<input id={id} className={`rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-slate-100 outline-none focus:border-cyan-400 ${className}`} {...props} /></label>
}
