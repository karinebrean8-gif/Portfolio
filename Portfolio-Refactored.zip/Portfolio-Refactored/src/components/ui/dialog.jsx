export function Dialog({ open, title, children, onClose }) {
  if (!open) return null
  return <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/80 p-4" role="presentation" onMouseDown={onClose}><section className="max-h-[85vh] w-full max-w-2xl overflow-auto rounded-2xl border border-slate-700 bg-slate-900 p-6" role="dialog" aria-modal="true" aria-labelledby="dialog-title" onMouseDown={(event) => event.stopPropagation()}><div className="flex items-start justify-between gap-4"><h2 id="dialog-title" className="text-2xl font-bold">{title}</h2><button type="button" className="rounded px-2 py-1 text-slate-300 hover:bg-slate-800" onClick={onClose} aria-label="Close dialog">×</button></div><div className="mt-4">{children}</div></section></div>
}
