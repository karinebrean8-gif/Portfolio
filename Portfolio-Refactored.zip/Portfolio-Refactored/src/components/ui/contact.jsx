import { useState } from 'react'
import { Button } from './button.jsx'
import { Input } from './input.jsx'

export function ContactForm({ email }) {
  const [message, setMessage] = useState('')
  const handleSubmit = (event) => {
    event.preventDefault()
    const data = new FormData(event.currentTarget)
    const subject = encodeURIComponent(`Portfolio enquiry from ${data.get('name')}`)
    const body = encodeURIComponent(String(data.get('message') || ''))
    window.location.href = `mailto:${email}?subject=${subject}&body=${body}`
    setMessage('Your email application should open now.')
  }
  return <form className="grid gap-4" onSubmit={handleSubmit}><Input id="name" name="name" label="Name" required /><Input id="email" name="email" label="Email" type="email" required /><label className="grid gap-2 text-sm font-medium text-slate-200" htmlFor="message">Message<textarea id="message" name="message" rows="5" className="rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 outline-none focus:border-cyan-400" required /></label><Button type="submit">Send message</Button><p className="text-sm text-slate-400" aria-live="polite">{message}</p></form>
}
