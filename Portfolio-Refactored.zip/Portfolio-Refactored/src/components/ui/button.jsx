const variants = {
  primary: 'bg-cyan-400 text-slate-950 hover:bg-cyan-300 focus-visible:outline-cyan-300',
  secondary: 'border border-slate-700 bg-slate-900/70 text-slate-100 hover:border-cyan-400',
}

export function Button({ as: Element = 'button', variant = 'primary', className = '', ...props }) {
  return <Element className={`inline-flex items-center justify-center rounded-lg px-4 py-2 font-semibold transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 ${variants[variant]} ${className}`} {...props} />
}
