#!/usr/bin/env sh
set -eu
IMAGE="${IMAGE:-portfolio:local}"
docker build -t "$IMAGE" .
echo "Built $IMAGE. Push and deploy it through your approved release pipeline."
