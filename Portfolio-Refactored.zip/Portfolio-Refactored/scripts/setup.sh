#!/usr/bin/env sh
set -eu
command -v node >/dev/null 2>&1 || { echo 'Node.js is required' >&2; exit 1; }
npm install --no-audit --no-fund
npm run check
