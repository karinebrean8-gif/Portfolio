type SeedRecord = Readonly<{ id: string; label: string }>
const seedRecords: readonly SeedRecord[] = [{ id: 'portfolio', label: 'Portfolio project' }]
const run = async (): Promise<void> => { await Promise.resolve(); console.info(`Prepared ${seedRecords.length} seed record(s). Connect this script to a real database before production use.`) }
run().catch((error: unknown) => { console.error(error); process.exitCode = 1 })
