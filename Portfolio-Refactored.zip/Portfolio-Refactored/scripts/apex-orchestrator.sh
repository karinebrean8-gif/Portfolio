#!/usr/bin/env sh
set -eu
npm run lint
npm run test
npm run build
