import { describe, expect, it } from 'vitest'
type State = Readonly<{ query: string }>
const setQuery = (state: State, query: string): State => ({ ...state, query })
describe('immutable state updates', () => { it('returns a new object without mutating the previous state', () => { const initial: State = { query: '' }; const next = setQuery(initial, 'react'); expect(next).toEqual({ query: 'react' }); expect(initial).toEqual({ query: '' }); expect(next).not.toBe(initial) }) })
