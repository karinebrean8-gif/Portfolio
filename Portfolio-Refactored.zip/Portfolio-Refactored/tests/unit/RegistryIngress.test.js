import { describe, expect, it } from 'vitest'
import { Registry } from '../../src/components/features/skills/services/RegistryIngress.js'
describe('Registry', () => { it('registers and resolves a dependency', () => { const registry = new Registry().register('logger', { enabled: true }); expect(registry.resolve('logger')).toEqual({ enabled: true }) }); it('rejects unknown keys', () => { expect(() => new Registry().resolve('missing')).toThrow(/No registry entry/) }) })
