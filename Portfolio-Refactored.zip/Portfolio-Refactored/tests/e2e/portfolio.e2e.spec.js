import { expect, test } from '@playwright/test'
test('renders the portfolio and primary navigation', async ({ page }) => { await page.goto('/'); await expect(page.getByRole('heading', { level: 1 })).toContainText('Build reliable products'); await expect(page.getByRole('navigation')).toBeVisible() })
