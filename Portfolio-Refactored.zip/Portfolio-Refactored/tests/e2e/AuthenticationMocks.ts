export const authenticatedUser = Object.freeze({ id: 'test-user', name: 'Test User', roles: ['viewer'] as const })
