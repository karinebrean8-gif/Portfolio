import { describe, expect, it } from 'vitest'
describe('database configuration', () => { it('does not claim a connection without a database URL', () => { const databaseUrl = process.env.DATABASE_URL; expect(databaseUrl === undefined || databaseUrl.startsWith('postgres')).toBe(true) }) })
