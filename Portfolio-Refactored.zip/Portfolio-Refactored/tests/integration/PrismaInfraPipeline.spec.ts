import { describe, expect, it } from 'vitest'
import { validateResponse } from '../../packages/prisma/api-response/validation.js'
describe('persistence response validation', () => { it('accepts a response with an ok field', () => { expect(validateResponse({ ok: true, data: [] })).toEqual({ valid: true, errors: [] }) }) })
