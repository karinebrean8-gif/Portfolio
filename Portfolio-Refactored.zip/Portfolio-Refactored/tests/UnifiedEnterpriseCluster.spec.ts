import { describe, expect, it } from 'vitest'
import { unique } from '../src/lib/collections.js'
describe('application foundations', () => { it('deduplicates values without mutating input', () => { const values = ['React', 'React', 'Vite']; expect(unique(values)).toEqual(['React', 'Vite']); expect(values).toHaveLength(3) }) })
