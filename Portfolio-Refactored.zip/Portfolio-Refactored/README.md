# Shakib Mia — Engineering Portfolio

A production-oriented portfolio built with React, Vite, and Tailwind CSS. The repository favors verifiable implementation, small modules, accessible interfaces, and documentation that matches the code.

## Highlights

- Feature-oriented React architecture
- Data-driven projects, skills, experience, certifications, and case studies
- Tailwind CSS 4 through the Vite plugin
- Unit and integration tests with Vitest
- Browser checks with Playwright
- Docker, Kubernetes, and Terraform examples
- Honest boundaries: infrastructure files are deployment templates, not claims of a live production platform

## Quick start

```bash
npm install --no-audit --no-fund
npm run dev
```

Open `http://localhost:5173`.

## Quality checks

```bash
npm run lint
npm run test
npm run build
npm run check
```

Browser tests require Playwright browsers:

```bash
npx playwright install
npm run build
npm run test:e2e
```

## Repository structure

```text
Portfolio/
├── infra/
│   ├── k8s/                 # Kubernetes deployment and service
│   ├── terraform/           # Minimal AWS infrastructure example
│   └── Orchestrator.mk      # Repeatable development commands
├── packages/
│   └── prisma/              # Optional persistence boundary and response helpers
├── public/                  # Static assets
├── scripts/                 # Setup, validation, and container build scripts
├── src/
│   ├── components/
│   │   ├── features/        # Case studies, certifications, experience, projects, skills
│   │   ├── layout/          # Navigation, sidebar, footer
│   │   └── ui/              # Reusable UI primitives
│   ├── data/                # Portfolio content
│   ├── lib/                 # Framework-independent utilities
│   ├── App.jsx
│   └── main.jsx
├── tests/
│   ├── unit/
│   ├── integration/
│   └── e2e/
├── Dockerfile
├── docker-compose.yml
├── package.json
└── vite.config.js
```

## Architecture

Dependencies point inward toward stable data and utility modules:

```text
Pages → feature components/hooks → shared UI/data/lib
Infrastructure adapters → explicit persistence interfaces
```

The application intentionally uses one frontend build system: **Vite**. Misplaced Next.js and custom server configuration were removed because they were not part of the executable application.

## Environment variables

Copy `.env.example` to `.env` and update public portfolio links. Only variables prefixed with `VITE_` are exposed to the browser.

## Containers

```bash
docker compose up --build
```

The site is then available at `http://localhost:8080`.

## Deployment notes

- Replace the example container image in `infra/k8s/deployment.yaml` with an immutable image tag.
- Configure a remote Terraform backend before collaborative use.
- Review cloud permissions, domains, TLS, monitoring, and budgets before deployment.
- Never commit secrets or real `.env` files.

## Engineering principles

This repository uses clear naming, immutable data where practical, small functions, explicit async boundaries, arrays/objects/`Map` where they fit the problem, and tests for behavior that actually exists. It deliberately avoids unverifiable labels such as “L19,” “ultra-FAANG,” or “50 years of experience”; recruiters can evaluate the executable code and documented decisions directly.

## License

Use the source as a learning reference. Replace personal content and links before publishing your own version.
