let clientPromise
export const getPrismaClient = async () => {
  if (!clientPromise) clientPromise = import('@prisma/client').then(({ PrismaClient }) => new PrismaClient()).catch((error) => { clientPromise = undefined; throw new Error('Prisma client is unavailable. Install @prisma/client and generate the client before use.', { cause: error }) })
  return clientPromise
}
export const disconnectPrisma = async () => { if (!clientPromise) return; const client = await clientPromise; await client.$disconnect(); clientPromise = undefined }
