export const success = (data, meta = {}) => Object.freeze({ ok: true, data, meta })
export const failure = (code, message, details = null) => Object.freeze({ ok: false, error: { code, message, details } })
export { validateResponse } from './validation.js'
