export class PersistenceService {
  constructor(repository) { if (!repository) throw new TypeError('A repository implementation is required'); this.repository = repository }
  list(options = {}) { return this.repository.list(options) }
  findById(id) { if (!id) return Promise.resolve(null); return this.repository.findById(id) }
  create(input) { return this.repository.create(input) }
  update(id, input) { return this.repository.update(id, input) }
  remove(id) { return this.repository.remove(id) }
}
